package ir.sharif.math.ap2023.hw5;

public interface SourceReader {
    byte read();
}
